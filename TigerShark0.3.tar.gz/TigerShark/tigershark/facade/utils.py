def first(l):
    try:
        return l.pop()
    except Exception:
        return None
