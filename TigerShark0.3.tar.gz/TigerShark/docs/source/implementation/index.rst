##############
Implementation
##############

The API documentation defines the implementation.

..  toctree::
    :maxdepth: 2
    
    x12
    tools
    claims
    extras
    test
    
The following is an example Django application.

..  toctree::
    :maxdepth: 2

    web
    