================================
``web`` Django Project
================================

This is a sample implementation that uses a number of X12 message
parsing features.

..  automodule:: web