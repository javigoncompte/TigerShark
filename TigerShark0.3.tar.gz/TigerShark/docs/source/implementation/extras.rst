==================================
``extras.standardSegment`` Module
==================================

..  automodule:: extras.standardSegment
