insert into claims_groupstatus( name, description, can_change ) values ( 'Base', 'Initial Load', 'No' );
insert into claims_groupstatus( name, description, can_change ) values ( 'Benchmark', 'Benchmark', 'Yes' );
insert into claims_groupstatus( name, description, can_change ) values ( 'Pending', 'Work In Process', 'Yes' );
