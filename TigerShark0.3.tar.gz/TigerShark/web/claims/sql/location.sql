insert into claims_location( name, description ) values ( 'BUF', 'Buffalo');
insert into claims_location( name, description ) values ( 'ALB', 'Albany' );
insert into claims_location( name, description ) values ( 'CNYW', 'Central New York West');
insert into claims_location( name, description ) values ( 'CNYE', 'Central New York East' );
