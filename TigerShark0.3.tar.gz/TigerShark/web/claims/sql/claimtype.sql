insert into claims_claimtype( name, description ) values ( '837P', 'Professional' );
insert into claims_claimtype( name, description ) values ( '837I', 'Inpatient' );
insert into claims_claimtype( name, description ) values ( '837O', 'Outpatient' );
insert into claims_claimtype( name, description ) values ( '837D', 'Dental' );
