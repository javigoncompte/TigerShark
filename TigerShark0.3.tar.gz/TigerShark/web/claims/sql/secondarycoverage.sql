insert into claims_secondarycoverage( name, description ) values ( 'Regular', 'Regular' );
insert into claims_secondarycoverage( name, description ) values ( 'Medicare', 'Medicare' );
insert into claims_secondarycoverage( name, description ) values ( 'COB', 'COB' );
insert into claims_secondarycoverage( name, description ) values ( 'NASCO', 'NASCO' );
