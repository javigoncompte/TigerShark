BEGIN;
DROP TABLE "claims_x12segment";
DROP TABLE "claims_x12message";
DROP TABLE "claims_x12loop";
COMMIT;
